package main;

import java.io.File;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.http.Header;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import ch.qos.logback.classic.Logger;
import edu.uci.ics.crawler4j.crawler.Page;
import edu.uci.ics.crawler4j.crawler.WebCrawler;
import edu.uci.ics.crawler4j.parser.HtmlParseData;
import edu.uci.ics.crawler4j.url.WebURL;
import stat.CrawlStat;
import util.GetArticles;
import util.SaveImage;
import util.WriteCSV;

/**
 * @author Maolin Tu
 */
public class MyCrawler extends WebCrawler {

	private static final Pattern IMAGE_EXTENSIONS = Pattern.compile(".*\\.(bmp|gif|jpeg|jpg|png).*$");
	private static final Pattern FILTERS = Pattern.compile(
			".*(\\.(css|xml|js|mid|mp2|mp3|mp4|wav|avi|mov|mpeg|ram|m4v|svg" + "|rm|smil|wmv|swf|wma|zip|rar|gz" + ")).*$");

	private static final String START1 = "https://www.newsday.com/";
	private static final String START2 = "http://www.newsday.com/";
	private static final String START3 = "https://newsday.com/";
	private static final String START4 = "http://newsday.com/";
//	private static final String PAGE = "https://www.maolintu.com/page/";
	private static final Pattern CONTENT = Pattern.compile(".*[0-9]{4}\\/[0-9]{2}\\/[0-9]{2}.*$");
	// "https://www.maolintu.com/"
	/*
	 * some statistic variables
	 */
	int fetch_attempted = 0;

	/**
	 * You should implement this function to specify whether the given url should be
	 * crawled or not (based on your crawling logic).
	 */
	CrawlStat myCrawlStat; // Crawler status object

	/**
	 * constructor method
	 */
	public MyCrawler() {
		myCrawlStat = new CrawlStat();
	}
	
	@Override
	public boolean shouldVisit(Page referringPage, WebURL url) {
		String href = url.getURL();
		
		// write urls_blog.csv
		if(href.startsWith(START1) || href.startsWith(START2)||href.startsWith(START3) || href.startsWith(START4)) {
			WriteCSV.write(href, "OK", "urls_Newsday");
		}else {
			WriteCSV.write(href, "N_OK", "urls_Newsday");
		}
//		// Image files are always distributed by CDN, so ignore the url limitation
//		if (IMAGE_EXTENSIONS.matcher(href).matches()) {
//			return true;
//		}
		// Ignore the url if it has an extension that matches our defined set of image
		// extensions.
		if (FILTERS.matcher(href).matches()) {
			return false;
		}

		// Only accept the url if it is in the "www.maolintu.com" domain and protocol is
		// "https".
		
		return href.startsWith(START1) || href.startsWith(START2)||href.startsWith(START3) || href.startsWith(START4);
	}
	/**
	 * This function is called before visit()
	 */
	@Override
	protected void handlePageStatusCode(WebURL webUrl, int statusCode, String statusDescription) {
		myCrawlStat.addFetchAttempted();
		// write fetch_blog.csv
		WriteCSV.write(webUrl.getURL(), String.valueOf(statusCode), "fetch_Newsday");
		myCrawlStat.statusCode.put(statusCode, myCrawlStat.statusCode.getOrDefault(statusCode, 0)+1);
		if (statusCode >= 200 && statusCode < 300) {
			myCrawlStat.addFetchSucceed();
		} else if (statusCode >= 300 && statusCode < 400) {
			myCrawlStat.addFetchAborted();
		} else if (statusCode >= 400) {
			myCrawlStat.addFetchFailed();
		}

	}

	/**
	 * This function is called when a page is fetched and ready to be processed by
	 * your program.
	 */
	@Override
	public void visit(Page page) {
		int fileSize = page.getContentData().length;
		String url = page.getWebURL().getURL();
		String contentType = page.getContentType();
		if (contentType.startsWith("text/html")) {
			contentType = "text/html";
		}
		myCrawlStat.contentType.put(contentType, myCrawlStat.contentType.getOrDefault(contentType, 0)+1);
		String[] contents = new String[4];
		contents[0] = url;
		contents[1] = String.valueOf(fileSize);
		contents[2] = "0";
		contents[3] = contentType;
		logger.info("Visit URL: {}", url);
		logger.info("Visit size: {}", fileSize);
		
		if(fileSize<1024) {
			myCrawlStat.size1++;
		}else if(fileSize<1024*10) {
			myCrawlStat.size10++;
		}else if(fileSize<1024*100) {
			myCrawlStat.size100++;
		}else if(fileSize<1024*1000) {
			myCrawlStat.size1000++;
		}else{
			myCrawlStat.size10000++;
		}
		
		if (page.getParseData() instanceof HtmlParseData) {
			HtmlParseData htmlParseData = (HtmlParseData) page.getParseData();
			Set<WebURL> links = htmlParseData.getOutgoingUrls();
			logger.debug("Number of outgoing links: {}", links.size());
			contents[2] = String.valueOf(links.size());
			myCrawlStat.totalURL +=links.size();
			for(WebURL link: links) {
				if(myCrawlStat.uniqueURLs.add(link.getURL())) {
					if(link.getURL().startsWith(START1) || link.getURL().startsWith(START2)||link.getURL().startsWith(START3) || link.getURL().startsWith(START4)) {
						myCrawlStat.uniqueInURLs.add(link.getURL());
					}
				}
			}
		} else {
			logger.debug("Number of outgoing links: {}", 0);
		}
		logger.info("Visit type: {}", contentType);
		// write visit_blog.csv
		WriteCSV.write(contents, "visit_Newsday");

		
		
	}

	@Override
	public void onBeforeExit() {
		logger.info("Fetch Attempted {}: ", myCrawlStat.getFetchAttempted());
		logger.info("Fetch Succeed {}: ", myCrawlStat.getFetchSucceed());
		logger.info("Fetch Aborted {}: ", myCrawlStat.getFetchAborted());
		logger.info("Fetch Failed {}: ", myCrawlStat.getFetchFailed());
	}

	@Override
	public Object getMyLocalData() {
		return myCrawlStat;
	}
}
