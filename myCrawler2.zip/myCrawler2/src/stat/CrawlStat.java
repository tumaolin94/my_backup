package stat;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author Maolin Tu
 */
public class CrawlStat {
	private long fetchAttempted = 0;
	private long fetchSucceed = 0;
	private long fetchFailed = 0;
	private long fetchAborted = 0;
	
	public long totalURL = 0;
	public long uniqueURL = 0;
	public long uniqueInURL = 0;
	public long uniqueOutURL = 0;
	
	public Set<String> uniqueURLs = new HashSet<>();
	public Set<String> uniqueInURLs = new HashSet<>();
	public Set<String> uniqueOutURLs = new HashSet<>();
	public Map<Integer, Integer> statusCode = new HashMap<>();
	
	public Map<String, Integer> contentType = new HashMap<>();
	public long size1 = 0;
	public long size10 = 0;
	public long size100 = 0;
	public long size1000 = 0;
	public long size10000 = 0;
	/**
	 * count of fetch Attempted add 1
	 * */
	public void addFetchAttempted() {
		fetchAttempted++;
	}
	
	/**
	 * get fetchAttempted
	 * @return fetchAttempted 
	 */
	public long getFetchAttempted() {
		return fetchAttempted;
	}
	/**
	 * count of fetch Succeed add 1
	 * */
	public void addFetchSucceed() {
		fetchSucceed++;
	}
	
	/**
	 * get fetchSucceed
	 * @return fetchSucceed 
	 */
	public long getFetchSucceed() {
		return fetchSucceed;
	}
	/**
	 * count of fetch Failed add 1
	 * */
	public void addFetchFailed() {
		fetchFailed++;
	}
	
	/**
	 * get fetchFailed
	 * @return fetchFailed 
	 */
	public long getFetchFailed() {
		return fetchFailed;
	}
	/**
	 * count of fetch Aborted add 1
	 * */
	public void addFetchAborted() {
		fetchAborted++;
	}
	
	/**
	 * get fetchAborted
	 * @return fetchAborted 
	 */
	public long getFetchAborted() {
		return fetchAborted;
	}
}
